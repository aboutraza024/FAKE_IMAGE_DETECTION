from torchvision.transforms import Compose, Resize, ToTensor, Normalize
from PIL import Image
import torch

def preprocess_image(image_path):
    transform = Compose([
        Resize((256, 256)),
        ToTensor(),
        Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])

    try:
        img = Image.open(image_path).convert('RGB')
    except FileNotFoundError:
        print(f"Error: File not found at {image_path}")
        return None

    img_tensor = transform(img).unsqueeze(0)
    return img_tensor


def predict_image(model, image_path):
    img_tensor = preprocess_image(image_path)
    if img_tensor is None:
        return "Error: Image loading failed."

    with torch.no_grad():
        output = model(img_tensor)
        _, predicted_class = torch.max(output, 1)

    class_labels = {0: "Fake", 1: "Real"}
    return class_labels[predicted_class.item()]


