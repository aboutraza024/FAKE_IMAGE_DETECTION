# import random
#
# def v_code():
#     return random.randint(10000, 99999)
#
# # Example usage:
# verification_code = v_code()
# print(f"Generated 5-digit number: {verification_code}")

from fastapi import FastAPI, Form
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.requests import Request

app = FastAPI()

# Set up the templates directory
templates = Jinja2Templates(directory="templates")

@app.get("/", response_class=HTMLResponse)
async def render_form(request: Request):
    return templates.TemplateResponse("check.html", {"request": request})

@app.post("/submit-form")
async def submit_form(username: str = Form(...), password: str = Form(...)):
    # Handle form data here
    return {"username": username, "password": password}



if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)