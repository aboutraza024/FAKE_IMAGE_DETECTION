from torchvision.transforms import Compose, Resize, ToTensor, Normalize
from PIL import Image
import torch
from model import predict_image

model_path = r'C:\Users\hp\Desktop\SE\model\ViT\ViT.pth'
vit_model = torch.load(model_path, map_location=torch.device('cpu'))
vit_model.eval()  # Set the model to evaluation mode

image_path = r'D:\pictures\4.jpg'

try:
    prediction = predict_image(vit_model, image_path)
    print(f"The image is classified as: {prediction}")
except Exception as e:
    print(f"An error occurred: {e}")

